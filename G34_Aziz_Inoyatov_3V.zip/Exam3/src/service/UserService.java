package service;

import domain.Book;
import domain.User;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public interface UserService {
    Set<User> USERS = new HashSet<>();
    List<Book> MyBooks = new ArrayList<>();

    String Register(User user);
    void Login(User user);
    void Books(Book book);
}
