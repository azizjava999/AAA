package service;

import domain.Book;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public interface BookService {

    List<Book> BOOKS = new ArrayList<>();


    Book add(Book book);
    void showBooks();
    Book getByName(Book name);
    Book setbook(Book book);
}
