import Enums.Role;
import domain.Book;
import domain.User;
import impl.BookServiceImpl;
import impl.UserServiceImpl;
import service.BookService;
import service.UserService;

import java.time.LocalDateTime;
import java.util.Scanner;

import static service.BookService.BOOKS;
import static service.UserService.USERS;


public class Main {
    static Scanner ScInt = new Scanner(System.in);
    static Scanner ScStr = new Scanner(System.in);
    static BookService bookService = new BookServiceImpl();
    static UserService userService = new UserServiceImpl();

    public static void main(String[] args) {
        printMenu();
        System.out.print("""
                1.Register
                2.Login - """);
        int logged = ScInt.nextInt();
        if (logged == 1) {
            System.out.print("Enter name");
            String name = ScStr.nextLine();
            System.out.print("Enter phone number - ");
            String phone = ScStr.nextLine();
            User user = new User(name, LocalDateTime.now(), phone);
            userService.Register(user);
            Role.showRoles();
            int index = ScInt.nextInt();
            Role.getByIndex(index);
            switch (index) {
                case 1 -> {
                    System.out.println("1.Kitob olish\n2.Kitob berish\n3.Mening kitoblarim\n0.Exit - ");
                    int amal = ScInt.nextInt();
                    while (true) {
                        if (amal == 1) {
                            bookService.showBooks();
                            System.out.print("Which book do you want to read - ");
                            String bookname = ScStr.nextLine();
                            Book book = new Book(bookname);
                            bookService.getByName(book);
                            userService.Books(book);
                        } else if (amal == 2) {
                            System.out.print("Enter name of book - ");
                            String bookname = ScStr.nextLine();
                            Book book = new Book(bookname);
                            bookService.setbook(book);
                            userService.MyBooks.remove(book);
                        } else if (amal == 3) {
                            System.out.println(userService.MyBooks);
                        }
                    }
                }
            }
        } else if (logged == 2) {
            Role.showRoles();
            int index = ScInt.nextInt();
            Role.getByIndex(index);
            switch(index) {
            case 1 -> {
                System.out.println("1.Kitob olish\n2.Kitob berish\n3.Mening kitoblarim\n0.Exit - ");
                int amal = ScInt.nextInt();
                while (true) {
                    if (amal == 1) {
                        bookService.showBooks();
                        System.out.print("Which book do you want to read - ");
                        String bookname = ScStr.nextLine();
                        Book book = new Book(bookname);
                        bookService.getByName(book);
                        userService.Books(book);
                    } else if (amal == 2) {
                        System.out.print("Enter name of book - ");
                        String bookname = ScStr.nextLine();
                        Book book = new Book(bookname);
                        bookService.setbook(book);
                        userService.MyBooks.remove(book);
                    } else if (amal == 3) {
                        System.out.println(userService.MyBooks);
                    } else if (amal == 0) {
                        break;
                    }

                }

            }
        }
    }

}
    public static void printMenu() {
        System.out.println("==========Welcome to Library==========");
    }
}
