package Enums;

import static service.UserService.USERS;

public enum Role {
    READER(1),
    LIBRARIAN(2);
    private final int index;

    Role(int index) {
        this.index = index;
    }
    public static Role getByIndex(int index) {
        var roles = Role.values();
        for (Role role:roles) {
            if(role.index == index) {
                return role;
            }
        }
        return READER;
    }
    public static void showRoles() {
        var roles = Role.values();
        for (Role role:roles) {
            System.out.println(role.index + ")" + role);
        }
    }
    public int getIndex() {
        return index;
    }
}
