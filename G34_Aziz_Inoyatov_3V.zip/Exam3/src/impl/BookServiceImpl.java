package impl;

import domain.Book;
import service.BookService;

public class BookServiceImpl implements BookService {
    @Override
    public Book add(Book book) {
        BOOKS.add(book);
        return book;
    }

    @Override
    public void showBooks() {
        for (Book book:BOOKS) {
            System.out.println(book);
        }
    }

    @Override
    public Book getByName(Book name) {
        for (Book book:BOOKS) {
            if(book.equals(name)) {
                book.setBorrowed_user_id(false);
            }
        }
        return name;
    }

    @Override
    public Book setbook(Book book) {
        for (Book book1:BOOKS) {
            if(book1.equals(book)) {
                return book1;
            }
        }
        return null;
    }
}
