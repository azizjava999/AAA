package impl;

import domain.Book;
import domain.User;
import service.BookService;
import service.UserService;

public class UserServiceImpl implements UserService {


    @Override
    public String Register(User user) {
        for (User user1:USERS) {
            if(user.equals(user1)) {
                USERS.add(user);
            }
        }
        return null;
    }

    @Override
    public void Login(User user) {
        for (User user1:USERS) {
            if(user.equals(user1)) {
                System.out.println("==============================");
            }
        }
    }

    @Override
    public void Books(Book book) {
        System.out.println("=====MY BOOKS=====");
        MyBooks.add(book);
        return;
    }
}
