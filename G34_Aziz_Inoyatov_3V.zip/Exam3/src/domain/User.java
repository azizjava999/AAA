package domain;


import Enums.Role;

import java.time.LocalDateTime;

public class User {
    private Integer sequence = 0;
    {
        sequence++;
    }
    private int id = sequence;
    private String fullName;
    private String phoneNumber;
    private Role index = Role.READER;
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt;
    private Book books;

    public User() {
    }

    public User(String fullName, LocalDateTime createdAt, String phoneNumber) {
        this.fullName = fullName;
        this.createdAt = createdAt;
        this.phoneNumber = phoneNumber;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Role getIndex() {
        return index;
    }

    public void setIndex(Role index) {
        this.index = index;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Book getBooks() {
        return books;
    }

    public void setBooks(Book books) {
        this.books = books;
    }
}
