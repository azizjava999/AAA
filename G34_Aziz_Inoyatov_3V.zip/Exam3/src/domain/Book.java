package domain;

public class Book {
    private int sequence = 0;
    {
        sequence++;
    }

    private Integer id = sequence;
    private String name;
    private String author;
    private boolean borrowed_user_id = true;

    public Book() {
    }

    public Book(String name) {
        this.name = name;
    }

    public Book(String name, String author) {
        this.name = name;
        this.author = author;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isBorrowed_user_id() {
        return borrowed_user_id;
    }

    public void setBorrowed_user_id(boolean borrowed_user_id) {
        this.borrowed_user_id = borrowed_user_id;
    }

    @Override
    public String toString() {
        return "Book{" +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", borrowed_user_id=" + borrowed_user_id +
                '}';
    }
}
